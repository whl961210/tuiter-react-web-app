import React from "react";

function NotificationsScreen() {
    return <h1>Notifications</h1>;
   }
   export default NotificationsScreen;