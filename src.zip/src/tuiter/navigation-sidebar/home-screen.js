import React from 'react';

function HomeScreen() {
    return <h1>Home</h1>;
   }
   export default HomeScreen;