import React from "react";

function ListScreen() {
    return <h1>Lists</h1>;
   }
   export default ListScreen;