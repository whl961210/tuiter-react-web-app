import React from "react";

function MessageScreen() {
    return <h1>Messages</h1>;
   }
   export default MessageScreen;