import React from "react";
import TuitSummaryList from "../tuit-summary-list";

function ExploreScreen() {
    return (
      <div>
        <h1>Explore</h1>
        <TuitSummaryList/>
      </div>
    );
  }
  
  export default ExploreScreen;